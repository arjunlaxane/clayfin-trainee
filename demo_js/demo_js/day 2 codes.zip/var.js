// let a=90
// var a=67

// variable hoisting
console.log(a)
var a=90;